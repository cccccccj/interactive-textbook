# inkDml-Brackets-Extension
A Brackets code hinting extension for the inkDml project.

##Install

1. Install Brackets 1.0 or later.
2. In Brackets, click the menu item File > Extension Manager...
3. Go to the "Available" tab of the dialog that appears.
4. Drag the "brackets-inkdml.zip" file from Finder onto the box on the bottom left that says "Drag .zip here or Install from URL..."
